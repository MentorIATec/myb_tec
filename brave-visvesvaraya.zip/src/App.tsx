import React from "react";
import {
  Calendar,
  GraduationCap,
  Briefcase,
  Award,
  BookOpen,
  Users,
  ChevronRight,
  Star,
} from "lucide-react";
import ProfileHeader from "./ProfileHeader";
import Gallery from "./Gallery";
import Dashboard from "./Dashboard";
import Testimonials from "./Testimonials";
import Publications from "./Publications";
import Contact from "./Contact";
import "./styles.css";

const TimelineEvent = ({
  year,
  title,
  subtitle,
  icon,
  children,
  highlight,
}) => {
  const Icon = icon;

  return (
    <div className={`flex mb-8 ${highlight ? "animate-pulse" : ""}`}>
      <div className="mr-4 flex-shrink-0">
        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
          <Icon size={24} />
        </div>
        <div className="mt-1 text-center font-semibold text-gray-500">
          {year}
        </div>
      </div>
      <div className="flex-grow">
        <div
          className={`p-4 rounded-lg shadow-md ${
            highlight ? "bg-blue-50 border border-blue-200" : "bg-white"
          }`}
        >
          <h3 className="text-lg font-bold text-blue-800">{title}</h3>
          {subtitle && (
            <h4 className="text-md font-semibold text-gray-700 mb-2">
              {subtitle}
            </h4>
          )}
          <div className="text-gray-600">{children}</div>
        </div>
      </div>
    </div>
  );
};

const Skill = ({ children }) => (
  <span className="inline-block bg-blue-100 text-blue-800 rounded-full px-3 py-1 text-sm font-semibold mr-2 mb-2">
    {children}
  </span>
);

const App = () => {
  return (
    <div className="p-6 max-w-4xl mx-auto bg-gray-50 rounded-xl">
      {/* HEADER CON FOTO PROFESIONAL */}
      <ProfileHeader />

      {/* ÁREAS DE EXPERTISE RELACIONADAS CON LA VACANTE */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-blue-800 mb-4 flex items-center">
          <Star className="mr-2" size={24} />
          Competencias Clave para Coordinación de Mentores
        </h2>
        <div className="flex flex-wrap">
          <Skill>Liderazgo y Gestión de Equipos</Skill>
          <Skill>Acompañamiento Estudiantil</Skill>
          <Skill>Gestión basada en Datos</Skill>
          <Skill>Capacitación y Desarrollo de Talento</Skill>
          <Skill>Planificación Estratégica</Skill>
          <Skill>Colaboración Interinstitucional</Skill>
          <Skill>Detección y Manejo de Alertas Tempranas</Skill>
          <Skill>Mejora Continua de Procesos</Skill>
        </div>
      </div>

      {/* DASHBOARD DE MÉTRICAS */}
      <Dashboard />

      {/* TESTIMONIOS DE ESTUDIANTES */}
      <Testimonials />

      {/* LÍNEA DEL TIEMPO - ORDEN CRONOLÓGICO INVERTIDO */}
      <h2 className="text-2xl font-bold text-blue-800 mt-10 mb-6 text-center">
        Trayectoria Profesional
      </h2>
      <div className="border-l-4 border-blue-200 pl-8 ml-6">
        {/* 2025 */}
        <TimelineEvent
          year="2025"
          title="Formación Continua"
          subtitle="Certificaciones Recientes"
          icon={BookOpen}
        >
          <p>
            Análisis de datos: Diseño y Visualización de Tableros (Enero 2025)
          </p>
          <p>
            Evaluación de Innovaciones Educativas para Docentes (Enero 2025)
          </p>
          <p>
            Uso transversal-disciplinar de IA en el salón de clases (Enero 2025)
          </p>
          <p>
            Google Project Management: Professional Certificate (En proceso)
          </p>
          <p>Curso Counsious Business Center - Fred Koffman (En proceso)</p>
        </TimelineEvent>

        {/* 2024 */}
        <TimelineEvent
          year="2024-2025"
          title="Proyectos Estratégicos"
          subtitle="Tec de Monterrey"
          icon={Users}
          highlight={true}
        >
          <p>
            Representante de Campus Monterrey en el rediseño de la UF de
            mentoría para Plan 2026, integrando IA y tecnología educativa
          </p>
          <p>
            Postulación de 2 propuestas Novus relacionadas con la
            profesionalización de la labor de mentoría
          </p>
          <p>
            Creación de canal de comunicación Mentoría y Bienestar a través de
            SharePoint
          </p>
          <p>
            Participación en múltiples comités: Diseño e impartición de Semana
            Tec, Kick Off, Last Week Onboarding, Bienvenida de Transferencias
          </p>
        </TimelineEvent>

        {/* 2023-Presente */}
        <TimelineEvent
          year="2023-Presente"
          title="Mentora de éxito y bienestar estudiantil"
          subtitle="Tec de Monterrey, Campus Monterrey"
          icon={Briefcase}
          highlight={true}
        >
          <p>
            Desarrollo e implementación de sistemas de monitoreo y evaluación de
            KPIs utilizando herramientas avanzadas de análisis
          </p>
          <p>
            Gestión de procesos de mejora continua con resultados medibles:
            incremento del 94.5% en indicadores clave
          </p>
          <p>ECOA 2024 = 94.4, con 88.46% de opiniones entre 9 y 10</p>
          <p>HMS 2024 - 100% de participación</p>
          <p>
            Proyecto "Redefiniendo tu propósito de vida" para candidatos a
            graduación, impactando a más de 500 estudiantes
          </p>
        </TimelineEvent>

        {/* 2023 Six Sigma */}
        <TimelineEvent
          year="2023"
          title="Six Sigma Yellow Belt"
          subtitle="International Lean Six Sigma"
          icon={Award}
        >
          <p>
            Certificación en metodologías de mejora continua y gestión de la
            calidad
          </p>
        </TimelineEvent>

        {/* 2023 Maestría en Educación */}
        <TimelineEvent
          year="2023"
          title="Maestría en Educación"
          subtitle="Tec de Monterrey"
          icon={GraduationCap}
          highlight={true}
        >
          <p>
            Tesis: Levels of Cognitive Processes Assisted by Machine Learning in
            STEM Education
          </p>
          <p>
            Especialidad en integración de inteligencia artificial en la
            asistencia de procesos de aprendizaje
          </p>
          <p>Presentación en Congreso Internacional de Educación WEEF</p>
          <p>
            Publicación de artículo de investigación en IEEE Xplore (publicación
            de prestigio en el ámbito de la ingeniería)
          </p>
        </TimelineEvent>

        {/* 2022 */}
        <TimelineEvent
          year="2022"
          title="Microsoft Office 365 Tech Savvy Niveles 1, 2 y 3"
          subtitle="Tec de Monterrey"
          icon={Award}
        >
          <p>
            Certificación en el uso avanzado de las herramientas de Microsoft
            Office 365
          </p>
        </TimelineEvent>

        {/* 2021-2023 */}
        <TimelineEvent
          year="2021-2023"
          title="Coordinadora Académica - Ingeniería en Biotecnología"
          subtitle="Tec de Monterrey, Campus Monterrey"
          icon={Briefcase}
        >
          <p>
            Liderazgo en proceso de acreditación CACEI, consiguiendo
            acreditación de 5 años (máximo logro posible)
          </p>
          <p>
            Desarrollo de planes de acción correctiva y preventiva basados en
            auditorías internas
          </p>
          <p>
            Coordinación con grupos de interés para alinear objetivos y
            establecer métricas de desempeño
          </p>
        </TimelineEvent>

        {/* 2021 */}
        <TimelineEvent
          year="2021"
          title="Diplomado en Innovación Educativa"
          subtitle="Tec de Monterrey"
          icon={BookOpen}
        >
          <p>
            Adquisición de metodologías de innovación aplicadas a la educación
          </p>
        </TimelineEvent>

        {/* 2017-2021 */}
        <TimelineEvent
          year="2017-2021"
          title="Profesora titular de ciencias"
          subtitle="Alfa Fundación"
          icon={Briefcase}
        >
          <p>
            Implementación de metodologías de medición y evaluación de impacto
          </p>
          <p>
            Desarrollo de documentación técnica y procedimientos operativos
            estándares
          </p>
          <p>
            Rediseño de Cursos de Ciencias y coordinación del Club de Ciencias
          </p>
        </TimelineEvent>

        {/* 2017 */}
        <TimelineEvent
          year="2017"
          title="Maestría en Ciencias con especialidad en Sistemas Ambientales"
          subtitle="Tec de Monterrey"
          icon={GraduationCap}
        >
          <p>
            Tesis: Characterization of Glycerol Carbonate Production in a
            Reactive Distillation Column
          </p>
          <p>Especialización en procesos de separación y tratamiento</p>
        </TimelineEvent>

        {/* 2014 */}
        <TimelineEvent
          year="2014"
          title="Ingeniera Química Administradora"
          subtitle="Tec de Monterrey"
          icon={GraduationCap}
        >
          <p>Especialidad en Gestión Ambiental</p>
        </TimelineEvent>
      </div>

      {/* PUBLICACIONES Y CONTRIBUCIONES ACADÉMICAS */}
      <Publications />

      {/* GALERÍA DE EVIDENCIAS (AL FINAL) */}
      <Gallery />

      {/* INFORMACIÓN DE CONTACTO */}
      <Contact />
    </div>
  );
};

export default App;
