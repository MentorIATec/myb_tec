import React from "react";
import { Mail, Linkedin, MapPin, Phone, Globe } from "lucide-react";

const Contact = () => {
  return (
    <div className="contact-container">
      <h2 className="contact-title">Información de Contacto</h2>

      <div className="contact-grid">
        <a href="mailto:kareng@tec.mx" className="contact-card">
          <div className="contact-icon-container">
            <Mail size={24} />
          </div>
          <div className="contact-info">
            <h3 className="contact-label">Email</h3>
            <p className="contact-value">karen.gvg@gmail.com</p>
          </div>
        </a>

        <a
          href="https://www.linkedin.com/in/karenguzmanvega"
          target="_blank"
          rel="noopener noreferrer"
          className="contact-card"
        >
          <div className="contact-icon-container">
            <Linkedin size={24} />
          </div>
          <div className="contact-info">
            <h3 className="contact-label">LinkedIn</h3>
            <p className="contact-value">in/karenguzmanvega</p>
          </div>
        </a>

        <div className="contact-card">
          <div className="contact-icon-container">
            <Phone size={24} />
          </div>
          <div className="contact-info">
            <h3 className="contact-label">Teléfono</h3>
            <p className="contact-value">8125624833</p>
          </div>
        </div>

        <div className="contact-card">
          <div className="contact-icon-container">
            <MapPin size={24} />
          </div>
          <div className="contact-info">
            <h3 className="contact-label">Ubicación</h3>
            <p className="contact-value">Escobedo, N.L., México</p>
          </div>
        </div>

        <a
          href="https://tec.mx"
          target="_blank"
          rel="noopener noreferrer"
          className="contact-card"
        >
          <div className="contact-icon-container">
            <Globe size={24} />
          </div>
          <div className="contact-info">
            <h3 className="contact-label">Institución</h3>
            <p className="contact-value">Tecnológico de Monterrey</p>
          </div>
        </a>
      </div>
    </div>
  );
};

export default Contact;
