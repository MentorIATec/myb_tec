import React from "react";
import { BookOpen, ExternalLink, Award, FileText } from "lucide-react";

const Publications = () => {
  // Datos de publicaciones y contribuciones académicas
  const publications = [
    {
      id: 1,
      title:
        "Exploring the Transformative Potential of Machine Learning in Engineering Education",
      journal: "IEEE Xplore",
      year: "2023",
      authors: "Guzmán Vega, K. A., et al.",
      doi: "10.1109/WEEF-GEDC54742.2023.10343631",
      url: "https://ieeexplore.ieee.org/abstract/document/10343631",
      conference:
        "2023 World Engineering Education Forum and Global Engineering Deans Council (WEEF-GEDC)",
      abstract:
        "Esta investigación explora cómo la integración de machine learning puede transformar los procesos educativos en ingeniería, mejorando los niveles de procesos cognitivos en estudiantes STEM.",
      type: "article",
      icon: FileText,
    },
    {
      id: 2,
      title:
        "Levels of Cognitive Processes Assisted by Machine Learning in STEM Education",
      institution: "Tecnológico de Monterrey",
      year: "2023",
      type: "thesis",
      description:
        "Tesis de maestría que investiga el impacto de las tecnologías de inteligencia artificial en los procesos cognitivos de estudiantes de disciplinas STEM.",
      icon: BookOpen,
    },
    {
      id: 3,
      title: "Presentación en Congreso Internacional de Educación WEEF",
      event: "World Engineering Education Forum",
      location: "Singapur",
      year: "2023",
      description:
        "Ponencia sobre la integración de Machine Learning como herramienta de asistencia en procesos educativos, recibida con gran interés por la comunidad académica internacional.",
      type: "conference",
      icon: Award,
    },
  ];

  return (
    <div className="publications-container">
      <h2 className="publications-title">
        <BookOpen size={24} className="publications-icon" />
        Publicaciones y Contribuciones Académicas
      </h2>

      <div className="publications-grid">
        {publications.map((pub) => {
          const Icon = pub.icon;
          return (
            <div key={pub.id} className="publication-card">
              <div className="publication-header">
                <div className="publication-icon-container">
                  <Icon size={20} className="publication-icon" />
                </div>
                <div className="publication-type">
                  {pub.type === "article"
                    ? "Artículo Científico"
                    : pub.type === "thesis"
                    ? "Tesis de Investigación"
                    : "Presentación en Congreso"}
                </div>
              </div>

              <h3 className="publication-title">{pub.title}</h3>

              <div className="publication-details">
                {pub.journal && (
                  <p className="publication-journal">
                    <span className="publication-label">Publicado en:</span>{" "}
                    {pub.journal}
                  </p>
                )}

                {pub.authors && (
                  <p className="publication-authors">
                    <span className="publication-label">Autores:</span>{" "}
                    {pub.authors}
                  </p>
                )}

                {pub.conference && (
                  <p className="publication-conference">
                    <span className="publication-label">Conferencia:</span>{" "}
                    {pub.conference}
                  </p>
                )}

                {pub.institution && (
                  <p className="publication-institution">
                    <span className="publication-label">Institución:</span>{" "}
                    {pub.institution}
                  </p>
                )}

                {pub.event && (
                  <p className="publication-event">
                    <span className="publication-label">Evento:</span>{" "}
                    {pub.event}, {pub.location}
                  </p>
                )}

                <p className="publication-year">
                  <span className="publication-label">Año:</span> {pub.year}
                </p>

                {pub.abstract && (
                  <p className="publication-abstract">{pub.abstract}</p>
                )}

                {pub.description && (
                  <p className="publication-description">{pub.description}</p>
                )}

                {pub.url && (
                  <a
                    href={pub.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="publication-link"
                  >
                    Ver publicación <ExternalLink size={16} />
                  </a>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Publications;
