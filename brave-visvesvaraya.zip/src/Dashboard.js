import React from "react";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import { TrendingUp, Users, Award, BookOpen } from "lucide-react";

const Dashboard = () => {
  // Datos para el gráfico de barras de indicadores clave de mentoría
  const keyIndicatorsData = [
    { name: "ECOA", value: 94.4, fill: "#1E40AF" },
    { name: "Retención", value: 95, fill: "#3B82F6" },
    { name: "HMS", value: 100, fill: "#60A5FA" },
  ];

  // Datos para el gráfico circular de satisfacción con el mentoreo
  const mentoringSatisfactionData = [
    { name: "Sobresalientes (9-10)", value: 88.46, fill: "#1E40AF" },
    { name: "Otras opiniones", value: 11.54, fill: "#BFDBFE" },
  ];

  // Datos de impacto en el programa de mentoría
  const mentorshipImpactData = [
    { name: "Estudiantes CAG impactados", students: 500, fill: "#1E40AF" },
    { name: "Retención primer ingreso", percentage: 95, fill: "#60A5FA" },
    { name: "Seguimiento a estudiantes", percentage: 100, fill: "#93C5FD" },
  ];

  // Datos de habilidades de liderazgo relevantes para la posición
  const leadershipSkillsData = [
    { name: "Gestión de Equipos", level: 95, fill: "#1E40AF" },
    { name: "Capacitación", level: 90, fill: "#3B82F6" },
    { name: "Análisis de Datos", level: 92, fill: "#60A5FA" },
    { name: "Mejora Continua", level: 96, fill: "#93C5FD" },
  ];

  // Función para formatear números en los tooltips
  const formatNumber = (value) => {
    if (value >= 100) {
      return `${value.toFixed(0)}%`;
    }
    return value.toFixed(1);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="dashboard-tooltip">
          <p className="dashboard-tooltip-label">{`${
            label || payload[0].name
          }`}</p>
          <p className="dashboard-tooltip-value">{`${formatNumber(
            payload[0].value
          )}${payload[0].value <= 100 ? "%" : ""}`}</p>
        </div>
      );
    }
    return null;
  };

  // Función para determinar si estamos en un dispositivo móvil
  const isMobile = () => {
    return window.innerWidth <= 768;
  };

  return (
    <div className="dashboard-container">
      <h2 className="dashboard-title">
        Métricas de Desempeño en Mentoría y Liderazgo
      </h2>

      <div className="dashboard-metrics-grid">
        {/* Tarjeta Indicadores Clave */}
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <TrendingUp size={24} />
            <h3>Indicadores Clave de Mentoría</h3>
          </div>
          <div className="dashboard-chart-container" style={{ height: 250 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={keyIndicatorsData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis domain={[0, 100]} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" nameKey="name" radius={[4, 4, 0, 0]}>
                  {keyIndicatorsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tarjeta Satisfacción con el Mentoreo */}
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <Award size={24} />
            <h3>Satisfacción con el Mentoreo</h3>
          </div>
          <div className="dashboard-chart-container" style={{ height: 250 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={mentoringSatisfactionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {mentoringSatisfactionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Impacto del Programa de Mentoría */}
      <div className="dashboard-impact-section">
        <div className="dashboard-card-header mb-4">
          <Users size={24} />
          <h3>Impacto del Programa de Mentoría</h3>
        </div>
        <div className="dashboard-metrics-list">
          {mentorshipImpactData.map((item, index) => (
            <div
              key={index}
              className="dashboard-metric-item"
              style={{ borderLeftColor: item.fill }}
            >
              <div className="dashboard-metric-value">
                {item.students
                  ? `${item.students}+`
                  : item.sessions
                  ? item.sessions
                  : `${item.percentage}%`}
              </div>
              <div className="dashboard-metric-name">{item.name}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Habilidades de Liderazgo - VERSIÓN MEJORADA PARA MÓVILES */}
      <div className="dashboard-impact-section mt-4">
        <div className="dashboard-card-header mb-4">
          <Award size={24} />
          <h3>Habilidades de Liderazgo para la Coordinación</h3>
        </div>
        <div className="dashboard-skills-container" style={{ height: 200 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={leadershipSkillsData}
              layout="vertical"
              margin={{ top: 10, right: 20, left: 120, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11 }} />
              <YAxis
                dataKey="name"
                type="category"
                width={115}
                tick={{ fontSize: 11 }}
                tickMargin={5}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="level"
                nameKey="name"
                radius={[0, 4, 4, 0]}
                animationDuration={1500}
                animationBegin={300}
                isAnimationActive={true}
              >
                {leadershipSkillsData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
