import React from "react";
import { GraduationCap, Briefcase, Star, Users } from "lucide-react";

const ProfileHeader = () => {
  return (
    <div className="profile-header">
      <div className="profile-header-content">
        <div className="profile-photo-container">
          {/* Utilizamos una imagen de placeholder, deberás reemplazarla con tu foto real */}
          <img
            src="/img/Mi_foto_de_perfil.JPG"
            alt="Karen Ariadna Guzmán Vega"
            className="profile-photo"
          />
        </div>

        <div className="profile-info">
          <h1 className="profile-name">Karen Ariadna Guzmán Vega</h1>
          <p className="profile-title">Candidata a Coordinadora de Mentores</p>

          <div className="profile-highlights">
            <div className="profile-highlight-item">
              <GraduationCap size={20} className="profile-highlight-icon" />
              <p>
                M.Ed. en Educación | M.C. en Sistemas Ambientales | Ing. Química
              </p>
            </div>

            <div className="profile-highlight-item">
              <Briefcase size={20} className="profile-highlight-icon" />
              <p>Mentora de Éxito y Bienestar Estudiantil, Tec de Monterrey</p>
            </div>

            <div className="profile-highlight-item">
              <Users size={20} className="profile-highlight-icon" />
              <p>Especialista en Acompañamiento y Desarrollo Estudiantil</p>
            </div>
          </div>
        </div>
      </div>

      <div className="profile-summary">
        <p>
          Profesional con amplia experiencia en mentoría estudiantil y gestión
          académica, comprometida con el desarrollo integral de los estudiantes.
          Cuento con capacidad para implementar sistemas de monitoreo basados en
          datos, coordinar equipos multidisciplinarios y asegurar el
          cumplimiento de estándares institucionales. Mi enfoque en la mejora
          continua y el acompañamiento estudiantil me posiciona idealmente para
          liderar y gestionar el equipo de Mentores Estudiantiles, contribuyendo
          al éxito del estudiante durante su vida en el Tec.
        </p>
      </div>
    </div>
  );
};

export default ProfileHeader;
