import React, { useState, useEffect } from "react";
import { MessageSquare, ChevronLeft, ChevronRight } from "lucide-react";

const Testimonials = () => {
  // Testimonios reales de estudiantes
  const testimonials = [
    {
      id: 1,
      text: "Mi mentora es Karen y debo decir que ha sido la mejor mentora a lo largo de todo lo que llevo de mi carrera, siempre me ha apoyado y he recurrido con ella a varias cosas mias, tanto de la uni como personales y siempre sabe que decir o como apoyarme, también en mi trayectoria en el campus, cuando estaba batallando con materias y cuando dude de si mi carrera era la indicada, siempre me ayudó y apoyó y siempre estuvo disponible, la quiero mucho.",
      author: "Sofía del Carmen Salas Torres",
    },
    {
      id: 2,
      text: "Cuando recién llegué a Monterrey desde Querétaro no sabía qué hacer. Me encontraba en una ciudad desconocida, lejos de mi familia, amigos y sin ningún apoyo. Trabajaba y estudiaba al mismo tiempo, a veces no me daba tiempo ni para hacer de comer y vivía estresado. Desde mi primer sesión con Karen supe que podía contar con ella... Nunca me sentí solo, de hecho ella me apoyó y calmó cuando la presión de la escuela y el trabajo era demasiada, me ayudó a poner en perspectiva todos mis objetivos, mis preocupaciones y mis planes. No habría podido salir adelante sin ella.",
      author: "Erick Alfredo García Huerta",
    },
    {
      id: 3,
      text: "Mi primer semestre fue, en su mayoría, una nueva experiencia. Como todos, me sentí un poco nervioso al no conocer a nadie. Afortunadamente, llegó el viernes y conocí a mi mentora. Su energía y actitud me ayudaron a sentirme bienvenido. Karen ha sido una gran mentora y amiga. Más que nada, es un ejemplo para mí.",
      author: "Rodrigo Villegas Guerrero",
    },
    {
      id: 4,
      text: "Soy una persona muy curiosa pero a la vez tímida. Entonces al entrar al Tec tenía muchas dudas de cómo funcionaba todo y Karen siempre estuvo pendiente de mí y con increíble actitud. Me ayudó cuando estaba pensando cambiarme de carrera, me dió seguimiento e incluso ahora que me cambié, me siguió ayudado por whats con cualquier duda que tenía. Una gran mentora y persona.",
      author: "Sebastián Tsewang Herrera Treviño",
    },
    {
      id: 5,
      text: "Karen siempre está cuando la necesitamos. En muchas ocasiones he tenido sesiones 1 a 1 con ella, sus consejos siempre son de gran ayuda. Además, siempre tiene una respuesta a cualquier pregunta y un contacto para cualquier necesidad en específico.",
      author: "Angel Orlando Anguiano Peña",
    },
    {
      id: 6,
      text: "El semestre pasado tuve unos problemas con conducta estudiantil que iban más allá de lo aparente. Mi mentora (Karen) se me acercó para hablar porque estaba preocupada por mi y me escuchó. Su apoyo llega a tal punto de que hasta me fue a ayudar a realizar una cita en consejería estudiantil. Básicamente me apoyó en cada paso del proceso.",
      author: "Mario Saavedra Gómez",
    },
    {
      id: 7,
      text: "Cuando el semestre pasado tuve problemas para poder externar mi problema de discalculia la maestra me ayudó a poder animarme a platicar con mi directora y abrirme con mis profesores.",
      author: "Rebeca Quevedo Madrid",
    },
    {
      id: 8,
      text: "Al comienzo de mi vida en el tec como estudiante extranjero Karen fue un acompañamiento muy importante porque ella me resolvía todas las dudas que tenía o me indicaba con quién ir para que me lo resuelva.",
      author: "Ian Fernando León Hernández",
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoplay, setAutoplay] = useState(true);

  useEffect(() => {
    let intervalId;
    if (autoplay) {
      intervalId = setInterval(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
      }, 8000); // Cambiar cada 8 segundos
    }
    return () => clearInterval(intervalId);
  }, [autoplay, testimonials.length]);

  const goToPrevious = () => {
    setAutoplay(false);
    const isFirstSlide = currentIndex === 0;
    const newIndex = isFirstSlide ? testimonials.length - 1 : currentIndex - 1;
    setCurrentIndex(newIndex);
  };

  const goToNext = () => {
    setAutoplay(false);
    const isLastSlide = currentIndex === testimonials.length - 1;
    const newIndex = isLastSlide ? 0 : currentIndex + 1;
    setCurrentIndex(newIndex);
  };

  const goToSlide = (slideIndex) => {
    setAutoplay(false);
    setCurrentIndex(slideIndex);
  };

  return (
    <div className="testimonials-container">
      <h2 className="testimonials-title">
        <MessageSquare size={24} className="testimonials-icon" />
        Impacto en Estudiantes: Testimonios Reales
      </h2>

      <div className="testimonials-carousel">
        <div className="testimonial-card">
          <div className="testimonial-quote">"</div>
          <p className="testimonial-text">{testimonials[currentIndex].text}</p>
          <p className="testimonial-author">
            — {testimonials[currentIndex].author}
          </p>
        </div>

        <div className="testimonials-navigation">
          <button className="testimonial-nav-button" onClick={goToPrevious}>
            <ChevronLeft size={20} />
          </button>
          <div className="testimonials-dots">
            {testimonials.map((_, slideIndex) => (
              <div
                key={slideIndex}
                className={`testimonial-dot ${
                  slideIndex === currentIndex ? "testimonial-dot-active" : ""
                }`}
                onClick={() => goToSlide(slideIndex)}
              ></div>
            ))}
          </div>
          <button className="testimonial-nav-button" onClick={goToNext}>
            <ChevronRight size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Testimonials;
