import React, { useState } from "react";
import { ChevronLeft, ChevronRight, Image } from "lucide-react";

const Gallery = () => {
  // Datos de las imágenes (reemplaza estas URLs con tus propias imágenes)
  const images = [
    {
      id: 1,
      src: "img/WEEF.jpg",
      alt: "Presentación en Congreso WEEF",
      caption:
        "Presentación de investigación en el World Engineering Education Forum 2023",
    },
    {
      id: 2,
      src: "img/S18_ITC.JPG",
      alt: "Sesión de Semana 18 en colaboración con EIC",
      caption: "Actividad: Sesión de Semana 18 en colaboración con EIC",
    },
    {
      id: 3,
      src: "img/KREIburguesada.jpg",
      alt: "Vivencia estudiantil",
      caption:
        "Colaboración en planeación y ejecución de eventos de Vivencia Estudiantil",
    },
    {
      id: 4,
      src: "img/S18.jpg",
      alt: "Outreach",
      caption:
        "Contribución en la organización de eventos estratégicos para el acompañamiento estudiantil",
    },
    {
      id: 5,
      src: "img/EIC.jpg",
      alt: "Vinculación con MDA",
      caption:
        "Vinculación con MDA en diferentes iniciativas y procesos académicos",
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const goToPrevious = () => {
    const isFirstSlide = currentIndex === 0;
    const newIndex = isFirstSlide ? images.length - 1 : currentIndex - 1;
    setCurrentIndex(newIndex);
  };

  const goToNext = () => {
    const isLastSlide = currentIndex === images.length - 1;
    const newIndex = isLastSlide ? 0 : currentIndex + 1;
    setCurrentIndex(newIndex);
  };

  const goToSlide = (slideIndex) => {
    setCurrentIndex(slideIndex);
  };

  return (
    <div className="gallery-container">
      <h2 className="gallery-title">Evidencia Visual de Logros</h2>

      <div className="gallery-slide-container">
        {/* Botón izquierdo */}
        <div
          className="gallery-arrow gallery-arrow-left"
          onClick={goToPrevious}
        >
          <ChevronLeft size={30} />
        </div>

        {/* Imagen principal */}
        <div className="gallery-slide">
          <img
            src={images[currentIndex].src}
            alt={images[currentIndex].alt}
            className="gallery-image"
          />
          <div className="gallery-caption">
            <p>{images[currentIndex].caption}</p>
          </div>
        </div>

        {/* Botón derecho */}
        <div className="gallery-arrow gallery-arrow-right" onClick={goToNext}>
          <ChevronRight size={30} />
        </div>
      </div>

      {/* Indicadores */}
      <div className="gallery-dots-container">
        {images.map((slide, slideIndex) => (
          <div
            key={slide.id}
            className={`gallery-dot ${
              slideIndex === currentIndex ? "gallery-dot-active" : ""
            }`}
            onClick={() => goToSlide(slideIndex)}
          ></div>
        ))}
      </div>
    </div>
  );
};

export default Gallery;
